======
:) EXPLOIT NOTES
======


Is :) a exploit?:
No, it is based on WeAreDevs.Api and is 100% safe! The source code is open source
at http://github.com/deniboi123/smile/ meaning you can view it and test for your
self!

Where is my Exe and DLL?
It has probally been deleted by your anti-virus. Make sure to exclude it from
your anti-virus. Since it is very complex, anti-viruses have no choice but
to delete it. 


Credits:
WeAreDevs.net, WeAreDevs.Api creators.